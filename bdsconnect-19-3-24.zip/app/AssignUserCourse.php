<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AssignUserCourse extends Model
{
    protected $table="assign_user_courses";
}
