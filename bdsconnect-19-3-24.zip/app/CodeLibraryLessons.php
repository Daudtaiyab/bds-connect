<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CodeLibraryLessons extends Model
{
    protected $table="code_library_lessons";
}
