<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CourseLession extends Model
{
    protected $table="course_lessons";
}
