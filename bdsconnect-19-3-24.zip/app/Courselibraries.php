<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Courselibraries extends Model
{
    protected $table="courselibraries";
}
