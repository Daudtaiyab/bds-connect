<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TblNotification extends Model
{
    protected $table='tbl_notifications';
}
