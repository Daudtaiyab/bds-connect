<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TeachingOtption extends Model
{
    protected $table="teachingoptions";
}
