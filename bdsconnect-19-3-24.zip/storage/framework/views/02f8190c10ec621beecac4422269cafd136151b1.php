<script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
    <script type="text/javascript" src="<?php echo e(asset('public/user/js')); ?>/datatables.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.13.1/js/dataTables.bootstrap5.min.js"></script>
    <script type="text/javascript" src="<?php echo e(asset('public/user/js')); ?>/menu-script.js"></script>
    <script type="text/javascript" src="<?php echo e(asset('public/user/js')); ?>/script.js"></script><?php /**PATH D:\xampp\htdocs\bds\resources\views/users/inc/footer.blade.php ENDPATH**/ ?>