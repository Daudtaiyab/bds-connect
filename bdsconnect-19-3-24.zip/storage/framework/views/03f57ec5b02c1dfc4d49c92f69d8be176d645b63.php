
    
    <?php $__env->startSection('content'); ?>
    <?php
    //echo"<pre>";print_r($sidebarArr);die;
    ?>
    <div class="div-padding" id="showRead">
        <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8">
          <div class="user-heading">
                <h1>Course Index</h1>
                <div class="line"></div>
            </div>
          <div class="indexing">
            <ul class="category">
              <?php if(isset($sidebarArr) && !empty($sidebarArr)): ?>
            <?php $__currentLoopData = $sidebarArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listArr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <?php if(in_array($listArr['cat_id'],[\Config::get('constants.paidPdf'),\Config::get('constants.freePdf')])): ?>
              <li>
                <ul class="category-level">
                  <?php if(isset($listArr['cat_name']) && !empty($listArr['cat_name'])): ?>
                    <?php $iii=0; ?>
                    <?php $__currentLoopData = $listArr['cat_level']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key1 => $sub_level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!in_array($listArr['cat_id'],[\Config::get('constants.paidVideo'),\Config::get('constants.freeVideo')])): ?>
                    
                  <li><span><?php echo e($sub_level['level_name']); ?></span>
                    <ul class="category-level-lesson">
                      <?php if(isset($sub_level['lesson_data']) && !empty($sub_level['lesson_data'])): ?>
                                <?php $__currentLoopData = $sub_level['lesson_data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $less): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li class="show_data" id="<?php echo e($less['lesson_id']); ?>" data-level="<?php echo e($sub_level['level_id']); ?>"><?php echo e($less['lesson_title']); ?></li>

                      <input type="hidden" name="next_prev[]" value="<?php echo e($less['lesson_id']); ?>" class="next_prev_<?php echo e($sub_level['level_id']); ?>" id="next_prev_<?php echo e($sub_level['level_id']); ?>">
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                    </ul>
                  </li>
                  <?php else: ?>
                  <!-- write code for Video -->
                    <li>
                    <ul class="category-level-lesson">
                      <li id="<?php echo e($sub_level['lesson_id']); ?>" data-level="raja" class="show_data"><?php echo e($sub_level['lesson_title']); ?></li>
                    </ul>
                  </li>
                  <!-- write code for Video -->
                  <input type="hidden" name="next_prev[]" value="<?php echo e($sub_level['lesson_id']); ?>" class="next_prev_raja" id="next_prev_raja">
                  <?php endif; ?> 
                <?php $iii++; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                  
                </ul>
              </li>
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
              
              
            </ul>
          </div>
        </div>
        <div class="col-md-2"></div>
      </div>
    </div>
    <script src="<?php echo e(asset('public/asset/js')); ?>/jquery-3.6.1.min.js"></script>
    <script>
        $(document).ready(function(){
            $('.show_data').click(function(){
                var lesson_id=$(this).attr('id');
                var data_level=$(this).attr('data-level');
                //alert(data_level);
                var myArr=[];
                $.each($("input[class=next_prev_"+data_level+"]"), function( index, item ) {
                  //What you want to do for every text input
                  myArr.push(item.value);
                });
                //alert(myArr);
               
                $.ajax({
                  url:'<?php echo e(route("ajax.getLessonData")); ?>',
                  method:'post',
                  type:'html',
                  data:{'_token':'<?php echo e(csrf_token()); ?>','lesson_id':lesson_id,'myArr':myArr},
                  success:function(data)
                  {
                    $('#showRead').html(data);
                  }
                });
            });

            // Next Previous logic start
              
            // Next Previous logic end


            //send query
            $('div').on('click','#send_query' ,function (event) {
            var subject=$('#subject').val();
            var question=$('#question').val();
            //console.log(subject);
            //console.log(question);
                $('#send_query').text('Sending...');
                $.ajax({
                      url:'<?php echo e(route("ajax.senEnquiry")); ?>',
                      method:'post',
                      type:'html',
                      data:{'_token':'<?php echo e(csrf_token()); ?>','subject':subject,'question':question},
                      success:function(data)
                      {
                        //$('#showRead').html(data);
                        //alert('Query has been sent');
                        $('#smsg').text('Query has been sent');
                        $('#question').val('');
                        $('#send_query').text('Send Query');
                        //$('.btn-close').trigger('click');
                        setTimeout(function() {
                              $('.btn-close').trigger('click');
                              $('#smsg').text('');
                          }, 1000);

                      }
                    });

            });
            //send enqury end
        });
    </script>
    
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('users.inc.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u421606900/domains/bdsconnect.in/public_html/resources/views/users/pdf/pdf_library.blade.php ENDPATH**/ ?>