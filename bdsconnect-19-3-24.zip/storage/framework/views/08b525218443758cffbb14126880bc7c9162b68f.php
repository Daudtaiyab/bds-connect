<div class="menu-logo">
        <img src="<?php echo e(asset('public/user/img')); ?>/bds.png">
        <i class="bi bi-x-lg"></i>
    </div>
    <?php
    //echo"<pre>";print_r($sidebarArr);die;
    ?>
    <ul class="cd-accordion cd-accordion--animated margin-top-lg margin-bottom-lg">
        <!-- start lopp -->
        <?php if(isset($sidebarArr) && !empty($sidebarArr)): ?>
            <?php $__currentLoopData = $sidebarArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listArr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <li class="cd-accordion__item cd-accordion__item--has-children">
            <input class="cd-accordion__input" type="checkbox" name ="group-<?php echo e($listArr['cat_id']); ?>" id="group-<?php echo e($listArr['cat_id']); ?>" <?php if(in_array($listArr['cat_id'],[\Config::get('constants.paidPdf'),\Config::get('constants.freePdf')])): ?><?php echo e('checked'); ?><?php endif; ?>>
            <!--<label class="cd-accordion__label cd-accordion__label--icon-folder pdf" for="group-<?php echo e($listArr['cat_id']); ?>"><span><i class="bi bi-file-earmark-pdf"></i> <?php echo e($listArr['cat_name']); ?></span></label>-->
            <ul class="cd-accordion__sub cd-accordion__sub--l1">
                
                <?php if(isset($listArr['cat_name']) && !empty($listArr['cat_name'])): ?>
                <?php $iii=0; ?>
                    <?php $__currentLoopData = $listArr['cat_level']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key1 => $sub_level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!in_array($listArr['cat_id'],[\Config::get('constants.paidVideo'),\Config::get('constants.freeVideo')])): ?>
                        <li class="cd-accordion__item cd-accordion__item--has-children">
                    <input class="cd-accordion__input" type="checkbox" name ="sub-group-<?php echo e($sub_level['level_id']); ?>" id="sub-group-<?php echo e($sub_level['level_id']); ?>"  <?php if(in_array($listArr['cat_id'],[\Config::get('constants.paidPdf'),\Config::get('constants.freePdf')]) && $iii==0): ?><?php echo e('checked'); ?><?php endif; ?>>
                    <label class="cd-accordion__label cd-accordion__label--icon-folder" for="sub-group-<?php echo e($sub_level['level_id']); ?>"><span><?php echo e($sub_level['level_name']); ?></span></label>
                    <ul class="cd-accordion__sub cd-accordion__sub--l2">
                            <?php if(isset($sub_level['lesson_data']) && !empty($sub_level['lesson_data'])): ?>
                                <?php $__currentLoopData = $sub_level['lesson_data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $less): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="cd-accordion__item"><a class="cd-accordion__label cd-accordion__label--icon-img show_data" href="#" id="<?php echo e($less['lesson_id']); ?>" data-level="<?php echo e($sub_level['level_id']); ?>"><span><?php echo e($less['lesson_title']); ?></span></a></li>
                                <input type="hidden" name="next_prev[]" value="<?php echo e($less['lesson_id']); ?>" class="next_prev_<?php echo e($sub_level['level_id']); ?>" id="next_prev_<?php echo e($sub_level['level_id']); ?>">
                                

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        
                        

                    </ul>
                </li>
                 <?php else: ?>
                <li class="cd-accordion__item"><a class="cd-accordion__label cd-accordion__label--icon-img show_data" href="#" id="<?php echo e($sub_level['lesson_id']); ?>" data-level="raja"><span><?php echo e($sub_level['lesson_title']); ?></span></a></li>

                <input type="hidden" name="next_prev[]" value="<?php echo e($sub_level['lesson_id']); ?>" class="next_prev_raja" id="next_prev_raja">
                
                <?php endif; ?> 
                <?php $iii++; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                
            </ul>
        </li>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <!-- end loop here............ -->
        <!-- <li class="cd-accordion__item cd-accordion__item--has-children">
            <input class="cd-accordion__input" type="checkbox" name ="group-2" id="group-2">
            <label class="cd-accordion__label cd-accordion__label--icon-folder video" for="group-2"><span><i class="bi bi-camera-video"></i> Video Library</span></label>
            <ul class="cd-accordion__sub cd-accordion__sub--l1">
                <li class="cd-accordion__item"><a class="cd-accordion__label cd-accordion__label--icon-img" href="#0"><span>Image</span></a></li>
                <li class="cd-accordion__item"><a class="cd-accordion__label cd-accordion__label--icon-img" href="#0"><span>Image</span></a></li>
            </ul>
        </li>
        <li class="cd-accordion__item cd-accordion__item--has-children">
            <input class="cd-accordion__input" type="checkbox" name ="group-3" id="group-3" checked>
            <label class="cd-accordion__label cd-accordion__label--icon-folder code" for="group-3"><span><i class="bi bi-file-earmark-code"></i> Code Library</span></label>
            <ul class="cd-accordion__sub cd-accordion__sub--l1">
                <li class="cd-accordion__item cd-accordion__item--has-children">
                    <input class="cd-accordion__input" type="checkbox" name ="sub-group-7" id="sub-group-7">
                    <label class="cd-accordion__label cd-accordion__label--icon-folder" for="sub-group-7"><span> Basic Scratch based Coding.</span></label>
                    <ul class="cd-accordion__sub cd-accordion__sub--l2">
                        <li class="cd-accordion__item"><a class="cd-accordion__label cd-accordion__label--icon-img" href="#0"><span>Motivation of children to Coding.</span></a></li>
                        <li class="cd-accordion__item"><a class="cd-accordion__label cd-accordion__label--icon-img" href="#0"><span>Introduction to Scratch.</span></a></li>
                        <li class="cd-accordion__item"><a class="cd-accordion__label cd-accordion__label--icon-img" href="#0"><span>Image</span></a></li>
                    </ul>
                </li>
                
                <li class="cd-accordion__item cd-accordion__item--has-children video">
                    <input class="cd-accordion__input" type="checkbox" name ="sub-group-8" id="sub-group-8">
                    <label class="cd-accordion__label cd-accordion__label--icon-folder" for="sub-group-8"><span> Advance Scratch based Coding.</span></label>
                    <ul class="cd-accordion__sub cd-accordion__sub--l2">
                        <li class="cd-accordion__item"><a class="cd-accordion__label cd-accordion__label--icon-img" href="#0"><span>Image</span></a></li>
                        <li class="cd-accordion__item"><a class="cd-accordion__label cd-accordion__label--icon-img" href="#0"><span>Image</span></a></li>
                        <li class="cd-accordion__item"><a class="cd-accordion__label cd-accordion__label--icon-img" href="#0"><span>Image</span></a></li>
                        <li class="cd-accordion__item"><a class="cd-accordion__label cd-accordion__label--icon-img" href="#0"><span>Image</span></a></li>
                        <li class="cd-accordion__item"><a class="cd-accordion__label cd-accordion__label--icon-img" href="#0"><span>Image</span></a></li>
                    </ul>
                </li>
                <li class="cd-accordion__item cd-accordion__item--has-children video">
                    <input class="cd-accordion__input" type="checkbox" name ="sub-group-9" id="sub-group-9">
                    <label class="cd-accordion__label cd-accordion__label--icon-folder" for="sub-group-9"><span> Migration from Scratch to Python.</span></label>
                    <ul class="cd-accordion__sub cd-accordion__sub--l2">
                        <li class="cd-accordion__item"><a class="cd-accordion__label cd-accordion__label--icon-img" href="#0"><span>Image</span></a></li>
                        <li class="cd-accordion__item"><a class="cd-accordion__label cd-accordion__label--icon-img" href="#0"><span>Image</span></a></li>
                        <li class="cd-accordion__item"><a class="cd-accordion__label cd-accordion__label--icon-img" href="#0"><span>Image</span></a></li>
                        <li class="cd-accordion__item"><a class="cd-accordion__label cd-accordion__label--icon-img" href="#0"><span>Image</span></a></li>
                        <li class="cd-accordion__item"><a class="cd-accordion__label cd-accordion__label--icon-img" href="#0"><span>Image</span></a></li>
                    </ul>
                </li>
            </ul>
        </li>
        <li class="cd-accordion__item cd-accordion__item--has-children">
            <input class="cd-accordion__input" type="checkbox" name ="group-4" id="group-4">
            <label class="cd-accordion__label cd-accordion__label--icon-folder quiz" for="group-4"><span><i class="bi bi-question-square"></i> Consolidation Quiz</span></label>
            <ul class="cd-accordion__sub cd-accordion__sub--l1">
                <li class="cd-accordion__item cd-accordion__item--has-children">
                    <input class="cd-accordion__input" type="checkbox" name ="sub-group-4" id="sub-group-4">
                    <label class="cd-accordion__label cd-accordion__label--icon-folder" for="sub-group-4"><span>Sub Group 3</span></label>
                    <ul class="cd-accordion__sub cd-accordion__sub--l2">
                        <li class="cd-accordion__item"><a class="cd-accordion__label cd-accordion__label--icon-img" href="#0"><span>Image</span></a></li>
                        <li class="cd-accordion__item"><a class="cd-accordion__label cd-accordion__label--icon-img" href="#0"><span>Image</span></a></li>
                    </ul>
                </li>
                <li class="cd-accordion__item"><a class="cd-accordion__label cd-accordion__label--icon-img" href="#0"><span>Image</span></a></li>
                <li class="cd-accordion__item"><a class="cd-accordion__label cd-accordion__label--icon-img" href="#0"><span>Image</span></a></li>
            </ul>
        </li> -->
    </ul><?php /**PATH /home/u421606900/domains/bdsconnect.in/public_html/resources/views/users/inc/sidebar.blade.php ENDPATH**/ ?>