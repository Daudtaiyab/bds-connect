<div class="pdf-content">
    <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8">
            <div class="user-heading">
                <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb" class="w-100">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#"><?php echo e($data['lessonData']->category_name); ?></a></li>
                     <?php if(!in_array($data['lessonData']->cat_id,[\Config::get('constants.freeVideo'),\Config::get('constants.paidVideo'),])): ?><li class="breadcrumb-item"><a href="#"><?php echo e($data['lessonData']->level_name); ?></a></li><?php endif; ?>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($data['lessonData']->lesson_title); ?></li>
                  </ol>
                </nav>
                <h1><?php echo e($data['lessonData']->lesson_title); ?></h1>
                <div class="line"></div>
            </div>
            <?php if(in_array($data['lessonData']->cat_id,[\Config::get('constants.freePdf'),\Config::get('constants.paidPdf'),])): ?>
                <div class="iframe-container">
                 <?php if($data['lessonData']->lesson_iframe_code==''): ?>
                    <h1><?php echo e(\Config::get('constants.noData')); ?></h1>
                  <?php else: ?>
                <?php echo $data['lessonData']->lesson_iframe_code; ?>

                <?php endif; ?>
            </div>
            <div class="buttons">
                <div class="previousbutton">
                    <?php if(isset($data['preP']) && !empty($data['preP'])): ?>
                    <button class="button nextPrevious" id="<?php echo e($data['preP']); ?>" data-level="<?php echo e($data['lessonData']->level_id); ?>"><i class="bi bi-chevron-left"></i> Previous Topic</button>
                    <?php endif; ?>
                </div>
                <div class="nextbutton">
                    <?php if(isset($data['preP']) && !empty($data['nextP'])): ?>
                    <button class="button nextPrevious" id="<?php echo e($data['nextP']); ?>" data-level="<?php echo e($data['lessonData']->level_id); ?>">Next Topic <i class="bi bi-chevron-right"></i></button>
                    <?php endif; ?>
                </div>
                <input type="hidden" name="next_prev[]" value="<?php echo e($data['preP']); ?>" class="next_prev_<?php echo e($data['lessonData']->level_id); ?>" id="next_prev_<?php echo e($data['lessonData']->level_id); ?>">

                <input type="hidden" name="next_prev[]" value="<?php echo e($data['nextP']); ?>" class="next_prev_<?php echo e($data['lessonData']->level_id); ?>" id="next_prev_<?php echo e($data['lessonData']->level_id); ?>">

            </div>
            <?php elseif(in_array($data['lessonData']->cat_id,[\Config::get('constants.freeVideo'),\Config::get('constants.paidVideo'),])): ?>
            <div class="iframe-container">
               <?php if($data['lessonData']->lesson_video==''): ?>
                    <h1><?php echo e(\Config::get('constants.noData')); ?></h1>
                  <?php else: ?>
                <?php echo $data['lessonData']->lesson_video; ?>

                <?php endif; ?>
            </div>
            <div class="buttons">
                
                <div class="previousbutton">
                    <?php if(isset($data['preP']) && !empty($data['preP'])): ?>
                    <button class="button nextPrevious" id="<?php echo e($data['preP']); ?>" data-level="raja"><i class="bi bi-chevron-left"></i> Previous Topic</button>
                    <?php endif; ?>
                </div>
                
                <div class="nextbutton">
                    <?php if(isset($data['preP']) && !empty($data['nextP'])): ?>
                    <button class="button nextPrevious" id="<?php echo e($data['nextP']); ?>" data-level="raja">Next Topic <i class="bi bi-chevron-right"></i></button>
                    <?php endif; ?>
                </div>
                <input type="hidden" name="next_prev[]" value="<?php echo e($data['preP']); ?>" class="next_prev_raja" id="next_prev_<?php echo e($data['lessonData']->level_id); ?>">

                <input type="hidden" name="next_prev[]" value="<?php echo e($data['nextP']); ?>" class="next_prev_raja" id="next_prev_raja">

            </div>
            <?php endif; ?>
            
        </div>
        <div class="col-md-2"></div>
    </div>
</div>
<button  type="button" id="dropdownMenuButton1" data-bs-toggle="modal" data-bs-target="#editmodal">
    <div class="floating-query-btn">
        <div class="btn-text">
            <p>Send Query On Email</p>
        </div>
        <div class="btn-circle">
            <i class="bi bi-chat-right-text"></i>
        </div>
    </div>
</button>
<div class="modal fade" id="editmodal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Send Your Query</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form method="post" action="google.com">
          <div class="modal-body">
            <div class="modal-form">
                <div class="mb-3">
                  <label for="exampleFormControlTextarea1" class="form-label">Question  <span style="color: green" id="smsg"></span></label>
                  <textarea class="form-control" id="question" rows="3" placeholder="Enter your Query Here..."></textarea>
                </div>

                <input type="hidden" name="subject" id="subject" value="<?php echo e($data['lessonData']->category_name); ?>  <?php if(!in_array($data['lessonData']->cat_id,[\Config::get('constants.freeVideo'),\Config::get('constants.paidVideo'),])): ?> > <?php echo e($data['lessonData']->level_name); ?> <?php endif; ?> > <?php echo e($data['lessonData']->lesson_title); ?>">
                <div class="d-flex justify-content-center align-items-center">
                    <button type="button" class="button" id="send_query" name="send_query">Send Query</button>
                </div>

            </div>
          </div>
      </form>
    </div>
  </div>
</div>
<script type="text/javascript">
    $(document).ready(function(){
    $('.nextPrevious').on('click',function(){
                var lesson_id=$(this).attr('id');
                var data_level=$(this).attr('data-level');
                //alert(data_level);
                var myArr=[];
                $.each($("input[class=next_prev_"+data_level+"]"), function( index, item ) {
                  //What you want to do for every text input
                  myArr.push(item.value);
                });
                //alert(myArr);
               
                $.ajax({
                  url:'<?php echo e(route("ajax.getLessonData")); ?>',
                  method:'post',
                  type:'html',
                  data:{'_token':'<?php echo e(csrf_token()); ?>','lesson_id':lesson_id,'myArr':myArr},
                  success:function(data)
                  {
                    $('#showRead').html(data);
                  }
                });
            });
    });
</script><?php /**PATH /home/swastihomedecor/bds.swastihomedecor.com/resources/views/users/pdf/lesson_data.blade.php ENDPATH**/ ?>