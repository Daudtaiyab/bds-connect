<?php if(isset($courseLevel) && !empty($courseLevel)): ?>
	<option value="">--Select Level-</option>
	<?php $__currentLoopData = $courseLevel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	
	<?php else: ?>
	<option value="">No data found</option>
<?php endif; ?><?php /**PATH /home/swastihomedecor/bds.swastihomedecor.com/resources/views/admin/course_lesson/getcourseLevel.blade.php ENDPATH**/ ?>