
    
    <?php $__env->startSection('content'); ?>
    <div class="div-padding" id="showRead">
        
        <div class="pdf-content">
            <div class="row">
                <div class="col-md-2"></div>
                <div class="col-md-8">
                    <div class="user-heading">
                        <h1>Motivation of children to Coding.</h1>
                        <div class="line"></div>
                    </div>
                    <div class="iframe-container">
                        <iframe src="https://docs.google.com/presentation/d/e/2PACX-1vTT3k_Bafy9pLUqPJk79c9QytRwDLUqJVL974J2KNEDIxxd_cg8o8LwCVbAi4l98qxATLkFQrGMa8K0/embed?start=false&loop=false&delayms=3000" frameborder="0" width="100%" height="100%" allowfullscreen="true" mozallowfullscreen="true" webkitallowfullscreen="true"></iframe>
                    </div>
                    <div class="buttons">
                        <div class="previousbutton">
                            <button class="button"><i class="bi bi-chevron-left"></i> Previous Topic</button>
                        </div>
                        <div class="nextbutton">
                            <button class="button">Next Topic <i class="bi bi-chevron-right"></i></button>
                        </div>
                    </div>
                </div>
                <div class="col-md-2"></div>
            </div>
        </div>
    </div>
    <script src="<?php echo e(asset('public/asset/js')); ?>/jquery-3.6.1.min.js"></script>
    <script>
        $(document).ready(function(){
            $('.show_data').click(function(){
                var lesson_id=$(this).attr('id');
                //alert(id);
                $.ajax({
                  url:'<?php echo e(route("ajax.getLessonData")); ?>',
                  method:'post',
                  type:'html',
                  data:{'_token':'<?php echo e(csrf_token()); ?>','lesson_id':lesson_id},
                  success:function(data)
                  {
                    $('#showRead').html(data);
                  }
                });
            });

            //send query
            $('div').on('click','#send_query' ,function (event) {
            var subject=$('#subject').val();
            var question=$('#question').val();
            //console.log(subject);
            //console.log(question);

                $.ajax({
                      url:'<?php echo e(route("ajax.senEnquiry")); ?>',
                      method:'post',
                      type:'html',
                      data:{'_token':'<?php echo e(csrf_token()); ?>','subject':subject,'question':question},
                      success:function(data)
                      {
                        //$('#showRead').html(data);
                      }
                    });

            });
            //send enqury end
        });
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('users.inc.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\bds\resources\views/users/pdf/pdf_library.blade.php ENDPATH**/ ?>