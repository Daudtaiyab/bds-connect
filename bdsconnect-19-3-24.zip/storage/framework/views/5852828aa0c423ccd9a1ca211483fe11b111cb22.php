
    <?php $__env->startSection('content'); ?>
<div class="div-padding">
                        <div class="row">
                            <div class="col-lg-3 col-md-6 col-sm-6 mb-3">
                                <div class="status-box">
                                    <h1><?php echo e($data['all_school']); ?></h1>
                                    <h6>Registered Schools</h6>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 mb-3">
                                <div class="status-box peach">
                                    <h1><?php echo e($data['active_active']); ?></h1>
                                    <h6>Active Schools</h6>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 mb-3">
                                <div class="status-box green">
                                    <h1><?php echo e($data['school_inactive']); ?></h1>
                                    <h6>Inactive Schools</h6>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 mb-3">
                                <div class="status-box blue">
                                    <h1><?php echo e($data['all_course']); ?></h1>
                                    <h6>Courses</h6>
                                </div>
                            </div>
                        </div>
                        <div class="registration-form-outer">
                                
                        </div>
                    </div>

        <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u421606900/domains/bdsconnect.in/public_html/resources/views/admin/school-registration.blade.php ENDPATH**/ ?>