<?php
$ActiveRoute=\Request::route()->getName();
?>
<i class="bi bi-x-lg"></i>
                    <div class="sidebar-logo">
                        <img src="<?php echo e(asset('public/asset/img')); ?>/bds.png">
                    </div>
                    <div class="sidebar-list">
                        <ul>
                            <a href="<?php echo e(url('/dashboard')); ?>" class="<?php echo e(in_array($ActiveRoute,['home']) ? 'active' : ''); ?>">
                                <li>
                                    <i class="flaticon-school"></i> <span>School Registration</span>
                                </li>
                            </a>
                            <!-- <a href="#">
                                <li>
                                    <i class="flaticon-archives"></i> <span>Create Schools</span>
                                </li>
                            </a> -->

                            <a href="<?php echo e(route('GelallLibrary')); ?>" class="<?php echo e(in_array($ActiveRoute,['addLibrary','editLibrary','GelallLibrary']) ? 'active' : ''); ?>">
                                <li>
                                    <i class="flaticon-edit"></i> <span>Course Level Management</span>
                                </li>
                            </a>
                            
                            <a href="<?php echo e(route('getallCourse')); ?>" class="<?php echo e(in_array($ActiveRoute,['getallCourse','addCourse','editCourse']) ? 'active' : ''); ?>">
                                <li>
                                    <i class="flaticon-edit"></i> <span>Course Management</span>
                                </li>
                            </a>
                            

                             <a href="<?php echo e(route('GetallLesson')); ?>" class="<?php echo e(in_array($ActiveRoute,['addLesson','editLesson','GetallLesson']) ? 'active' : ''); ?>">
                                <li>
                                    <i class="flaticon-edit"></i> <span>Course Lesson Management</span>
                                </li>
                            </a>

                             
                            <a href="<?php echo e(route('Registerschool')); ?>" class="<?php echo e(in_array($ActiveRoute,['Registerschool','downloadSchool','approvedSchool','AssignCourseToUser','AssignCourseToUserSave']) ? 'active' : ''); ?>">
                                <li>
                                    <i class="flaticon-verify"></i> <span>Registered Schools</span>
                                </li>
                            </a>
                        </ul>
                    </div><?php /**PATH /home/u421606900/domains/bdsconnect.in/public_html/resources/views/admin/inc/sidebar.blade.php ENDPATH**/ ?>