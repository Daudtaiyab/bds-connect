
    <?php $__env->startSection('content'); ?>
       <div class="div-padding">
                        <div class="admin-heading">
                            <h4>Registered Schools</h4>
                            <div class="line"></div>
                        </div>
                        <div class="filter-data">
                            <div class="row mb-4">
                                <div class="col-md-4">
                                    <div class="form-floating">
                                      <select class="form-select" id="status" name="status" aria-label="Floating label select example">
                                        <option selected disbaled value="">Select Status</option>
                                        <option value="1" <?php if(isset($_GET['status']) && $_GET['status']==1): ?><?php echo e("selected"); ?><?php endif; ?>>Active</option>
                                        <option value="2" <?php if(isset($_GET['status']) && $_GET['status']==2): ?><?php echo e("selected"); ?><?php endif; ?>>Inactive</option>
                                      </select>
                                      <label for="floatingSelect">Status</label>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <button class="btn btn-warning w-100 h-100" id="filter">Filter</button>
                                    
                                </div>
                                <div class="col-md-4">
                                    
                                    <?php 
                                     $statusU='';
                                    if(isset($_GET['status']) && !empty($_GET['status'])){
                                        $statusU=$_GET['status'];
                                    }
                                    ?>
                                    <a href="<?php echo e(route('downloadSchool')); ?>?status=<?php echo e($statusU); ?>"><button class="btn btn-success w-100 h-100">Export</button></a>
                                </div>
                            </div>
                            <?php echo $__env->make('layouts.noftification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="table-structure">
                            <table id="edittable" class="table-striped">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Operations</th>
                                        <th>School Name</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Address</th>
                                        <th>Courses</th>
                                        <th>Username</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(isset($userList) && !empty($userList)): ?>
                                        <?php $__currentLoopData = $userList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td>
                                                    

                                                    <div class="dropdown">
                                              <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                                                <i class="bi bi-three-dots-vertical"></i>
                                              </button>
                                              <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                                                <li><a class="dropdown-item" href="<?php echo e(route('approvedSchool',$item['id'])); ?>"><i class="bi bi-pencil-square"></i> Edit</a></li>
                                                <li><a class="dropdown-item" href="#"><a class="dropdown-item delete_btn" href="#"  data-id="<?php echo e($item['id']); ?>"><i class="bi bi-trash3"></i> Delete</a></li>
                                                <li><a class="dropdown-item" href="<?php echo e(route('AssignCourseToUser',$item['id'])); ?>"><i class="bi bi-arrow-return-right"></i> Assign</a></li>
                                                <?php
                                                //$today=date('Y-m-d');
                                                $fdate = date('d-m-Y');
                                                $tdate =date('d-m-Y',strtotime($item['validity']));
                                                $datetime1 = new DateTime($fdate);
                                                $datetime2 = new DateTime($tdate);
                                                $interval = $datetime1->diff($datetime2);
                                                $days = $interval->format('%R%a');//now do whatever you like with $days
                                                ?>
                                                <?php if($days<1): ?>
                                                <li><a class="dropdown-item portal_activate" href="<?php echo e(route('PortalActivate',$item['id'])); ?>" href="#"  data-id="<?php echo e($item['id']); ?>"><i class="bi bi-arrow-return-right"></i> Portal Activate Now</a></li>

                                                <?php endif; ?>
                                                

                                              </ul>
                                            </div>

                                                </td>
                                                <td class="table-name"><?php echo e($item['full_name']); ?></td>
                                                
                                                <td><?php echo e($item['email']); ?></td>
                                                <td><?php echo e($item['phone_number']); ?></td>
                                                <td class="table-address"><?php echo e($item['address']); ?></td>
                                                <td data-bs-toggle="tooltip" data-bs-placement="top" title="" data-bs-original-title="<?php echo e($item['assigned_course'][0]['usercourse']); ?>" class="table-courses"><?php echo e(strlen($item['assigned_course'][0]['usercourse'])>=20 ? substr($item['assigned_course'][0]['usercourse'], 0, 10)."....." : ''); ?></td>
                                                
                                                <td><?php echo e($item['username']); ?></td>
                                                <td class="status <?php if($item['status']==1): ?><?php echo e('active'); ?> <?php else: ?> <?php echo e('inactive'); ?> <?php endif; ?>"><span><?php if($item['status']==1): ?><?php echo e('Active'); ?> <?php else: ?> <?php echo e('Inactive'); ?> <?php endif; ?></span></td>
                                                
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                    
                                </tbody>
                            </table>
                        </div>
                    </div>
             <script src="<?php echo e(asset('public/asset/js')); ?>/jquery-3.6.1.min.js"></script>
    
    <script type="text/javascript">
        $(document).ready(function () {
            $('#edittable').DataTable({
                scrollY: true,
                scrollX: true,
            });

            // filter
            $('#filter').on('click',function(){
                var status=$('#status').val();
                document.location.href="<?php echo e(route('Registerschool')); ?>?status="+status;
            });

            // delete
            $('#edittable').on('click', ".delete_btn", function(event){
                event.preventDefault();

            //$('.delete_btn').click(function(){
                var data_id=$(this).attr('data-id');
                if(confirm('Are you sure want to delete record?'))
                {
                    document.location.href="<?php echo e(route('userDelete')); ?>?data_id="+data_id;
                }
                else
                {
                    return false;
                } 
            });

                // activate
             $('#edittable').on('click', ".portal_activate", function(event){
                event.preventDefault();

            //$('.delete_btn').click(function(){
                var data_id=$(this).attr('data-id');
                if(confirm('Are you sure want to Activate Portal of this user?'))
                {
                    document.location.href="<?php echo e(route('PortalActivate')); ?>?data_id="+data_id;
                }
                else
                {
                    return false;
                } 
            });

        });
    </script>        
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u421606900/domains/bdsconnect.in/public_html/resources/views/admin/school/registerd-school.blade.php ENDPATH**/ ?>