 <script src="<?php echo e(asset('public/asset/js')); ?>/jquery-3.6.1.min.js"></script>
    <script type="text/javascript" src="<?php echo e(asset('public/asset/js')); ?>/datatables.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.13.1/js/dataTables.bootstrap5.min.js"></script>
    <script type="text/javascript" src="<?php echo e(asset('public/asset/js')); ?>/admin-script.js"></script><?php /**PATH /home/u421606900/domains/bdsconnect.in/public_html/portal/resources/views/admin/inc/footer.blade.php ENDPATH**/ ?>