<?php if(session()->get('success')): ?>
<div class="alert alert-success"><?php echo e(session()->get('success')); ?></div>
<?php endif; ?>

<?php if(session()->get('fail')): ?>
<div class="alert alert-danger"><?php echo e(session()->get('fail')); ?></div>
<?php endif; ?>

<?php /**PATH /home/u421606900/domains/bdsconnect.in/public_html/resources/views/layouts/noftification.blade.php ENDPATH**/ ?>