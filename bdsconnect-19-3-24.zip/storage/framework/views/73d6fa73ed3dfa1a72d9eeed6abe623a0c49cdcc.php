<?php if(isset($CourseCategory) && !empty($CourseCategory)): ?>
	<option value="">--Select Level Categroy--</option>
	<?php $__currentLoopData = $CourseCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<option value="<?php echo e($item->id); ?>"><?php echo e($item->category_name); ?></option>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	
	<?php else: ?>
	<option value="">No data found</option>
<?php endif; ?><?php /**PATH /home/u421606900/domains/bdsconnect.in/public_html/resources/views/admin/course_library/getcategoryCourse.blade.php ENDPATH**/ ?>