
    <?php $__env->startSection('content'); ?>
       <div class="div-padding">
                        <div class="admin-heading">
                            <h4>All Courses Request</h4>
                            <div class="line"></div>
                        </div>
                        <div class="row">

                                        
                                        <div class="col-md-6">
                                            <div class="form-floating mb-3">
                                              <input type="text" class="form-control" id="floatingInput" placeholder="abcdefghij" required value="<?php echo e($data['userDetail']->first_name); ?>" disabled="">
                                              <label for="floatingInput">First Name</label>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-floating mb-3">
                                              <input type="text" class="form-control" id="floatingPassword" placeholder="Password" required value="<?php echo e($data['userDetail']->last_name); ?>" disabled="">
                                              <label for="floatingPassword">Last Name</label>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-floating mb-3">
                                              <input type="text" class="form-control" id="floatingInput" placeholder="abcdefghij" required value="<?php echo e($data['userDetail']->email); ?>" disabled="">
                                              <label for="floatingInput">Email</label>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-floating mb-3">
                                              <input type="text" class="form-control" id="floatingPassword" placeholder="Password" required value="<?php echo e($data['userDetail']->phone_number); ?>" disabled="">
                                              <label for="floatingPassword">Phone Number</label>
                                            </div>
                                        </div>
                                       
                        </div> 
                        <form method="post" action="<?php echo e(route('SaveApprovedRejectCourse')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="editId" value="<?php echo e($data['userDetail']->id); ?>">
                            <div class="products">
                                <div class="row d-flex justify-content-center align-items-center">
                                    <!-- start loop -->
                                    <?php if(isset($data['approvalCourse']) && !empty($data['approvalCourse'])): ?>
                                        <?php $__currentLoopData = $data['approvalCourse']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coursedata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-4 mb-4">
                                        <label for="codeyrockey_<?php echo e($coursedata['course_id']); ?>">
                                            <input type="checkbox" id="codeyrockey_<?php echo e($coursedata['course_id']); ?>" class="checkbox" value="<?php echo e($coursedata['course_id']); ?>" name="courseassign[]" >
                                            <div class="card">
                                                <div class="card-img">
                                                    <img src="<?php echo e(asset('public/uploads/product')); ?>/<?php echo e($coursedata['course_img']); ?>" width="100%">
                                                </div>
                                                <div class="card-info">
                                                    <p class="text-title"><?php echo e($coursedata['course_name']); ?> </p>
                                                    <div class="button no-border">Assign Course</div>
                                                </div>
                                            </div>
                                        </label>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                    <div class="col-md-6">
                                            <div class="form-floating mb-3">
                                              <select name="is_approved" id="is_approved" class="form-control">
                                                  <option value="0">Pending</option>
                                                  <option value="1">Approved</option>
                                                  <option value="2">Reject</option>
                                              </select>
                                              <label for="floatingInput">First Name</label>
                                            </div>
                                        </div>
                                    <div class="d-flex justify-content-center align-items-center w-100 ">
                                        <button type="submit" name="submit" class="button">Submit Approval</button>
                                    </div>
                                    
                                </div>
                            </div>
                        </form>    
                    </div>
             <script src="<?php echo e(asset('public/asset/js')); ?>/jquery-3.6.1.min.js"></script>
    
    <script type="text/javascript">
        $(document).ready(function () {
            $('#edittable').DataTable({
                scrollY: true,
                scrollX: true,
            });
        });
    </script>        
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/swastihomedecor/bds.swastihomedecor.com/resources/views/admin/course_approval/view_approval.blade.php ENDPATH**/ ?>