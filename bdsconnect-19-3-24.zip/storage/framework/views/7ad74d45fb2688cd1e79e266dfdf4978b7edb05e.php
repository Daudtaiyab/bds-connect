<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Bds Frontend | Login</title>
    <?php echo $__env->make('admin.inc.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('head'); ?>
</head>
<body class="admin-body">
    <div class="">
        <div class="white-box">
           <div class="admin-panel">
                <div class="sidebar-menu">
                    <?php echo $__env->make('admin.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
                <div class="menu-overlay"></div>
                <div class="rightbar">
                    <?php echo $__env->make('admin.inc.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
           </div>                
        </div>
    <?php echo $__env->make('admin.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('footer'); ?>
</body>
</html><?php /**PATH /home/u421606900/domains/bdsconnect.in/public_html/portal/resources/views/admin/layouts/layout.blade.php ENDPATH**/ ?>