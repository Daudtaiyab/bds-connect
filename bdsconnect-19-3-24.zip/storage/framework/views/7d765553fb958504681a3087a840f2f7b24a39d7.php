<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <title>Bds Frontend | Login</title>
    <?php echo $__env->make('users.inc.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('head'); ?>
</head>
<body>
<div class="menu-panel">
	<?php echo $__env->make('users.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('sidebar'); ?>
</div>
<div class="menu-overlay"></div>
<div class="rightbar">
    <div class="top-nav">
       <?php echo $__env->make('users.inc.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <?php echo $__env->yieldContent('navbar'); ?>
    </div>
    <?php echo $__env->yieldContent('content'); ?>
</div>
<?php echo $__env->make('users.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('footer'); ?>
</body>
</html><?php /**PATH /home/u421606900/domains/bdsconnect.in/public_html/resources/views/users/inc/layout.blade.php ENDPATH**/ ?>