
    <?php $__env->startSection('content'); ?>
    <?php
    $statusArr=[1=>'Active',0=>'Inactive'];
    ?>
<div class="div-padding">
                        <div class="registration-form-outer">
                            <div class="login-form">
                                <h4>Registration Approval</h4>
                                <div class="line"></div>
                                <form action="<?php echo e(route('SaveApproval')); ?>" method="post">
                                  <?php echo csrf_field(); ?>
                                  <input type="hidden" name="editId" value="<?php echo e($userData->id); ?>">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-floating mb-3">
                                              <input type="text" class="form-control" id="floatingInput" placeholder="abcdefghij" required value="<?php echo e($userData->first_name); ?>" name="first_name">
                                              <label for="floatingInput">School Name</label>
                                            </div>
                                        </div>
                                        <div class="col-md-6" style="display:none;">
                                            <div class="form-floating mb-3">
                                              <input type="text" class="form-control" id="floatingPassword" placeholder="Password" value="" name="last_name">
                                              <label for="floatingPassword">Last Name</label>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-floating mb-3">
                                              <input type="email" class="form-control" id="floatingPassword" placeholder="Password" required value="<?php echo e($userData->email); ?>" name="email">
                                              <label for="floatingPassword">Email Address</label>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-floating mb-3">
                                              <input type="text" class="form-control" id="floatingPassword" placeholder="Password" required value="<?php echo e($userData->phone_number); ?>" name="phone_number">
                                              <label for="floatingPassword">Phone Number</label>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-floating mb-3">
                                              <input type="text" class="form-control" id="floatingPassword" placeholder="Password" required value="<?php echo e($userData->username); ?>" name="username">
                                              <label for="floatingPassword">Username</label>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-floating mb-3">
                                              <input type="text" class="form-control" id="floatingPassword" placeholder="Password" required value="<?php echo e($userData->wifi_address); ?>" name="wifi_address">
                                              <label for="floatingPassword">Wifi Address</label>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-floating mb-3">
                                              <select id="status" name="status" class="form-control" required="">
                                                <?php $__currentLoopData = $statusArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skey=>$svalue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                  <option value="<?php echo e($skey); ?>" <?php if($skey==$userData->status): ?> <?php echo e("selected"); ?> <?php endif; ?>><?php echo e($svalue); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                
                                              </select>
                                              <label for="floatingPassword">Status</label>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                                <div class="form-floating mb-3">
                                                  <input type="text" class="form-control" id="address" name="address" placeholder="Address" required value="<?php echo e($userData->address); ?>">
                                                  <label for="floatingPassword">Address</label>
                                                  <span style="color: red;"><?php echo e($errors->first('address')); ?></span>
                                                </div>
                                            </div>

                                      <div class="col-md-6">
                                                <div class="form-floating mb-3">
                                                  <input type="date" class="form-control" id="validity" name="validity" placeholder="Address" required value="<?php echo e($userData->validity); ?>">
                                                  <label for="floatingPassword">Validity</label>
                                                  <span style="color: red;"><?php echo e($errors->first('address')); ?></span>
                                                </div>
                                            </div>      
                                       
                                    </div>  
                                     
                                    <div class="d-flex justify-content-center align-items-center w-100">
                                        <button type="submit" name="submit" class="button">Approve Now</button>
                                    </div>
                                </form>   
                            </div>    
                        </div>
                    </div>

        <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u421606900/domains/bdsconnect.in/public_html/resources/views/admin/school/approval_school.blade.php ENDPATH**/ ?>