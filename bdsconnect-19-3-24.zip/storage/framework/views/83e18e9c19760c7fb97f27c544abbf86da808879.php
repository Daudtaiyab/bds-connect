<?php if(isset($courseLevel) && !empty($courseLevel)): ?>
	<option value="">--Select Level-</option>
	<?php $__currentLoopData = $courseLevel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<option value="<?php echo e($item->id); ?>" selected=""><?php echo e($item->name); ?></option>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	
	<?php else: ?>
	<option value="1" selected="">No data found</option>
<?php endif; ?><?php /**PATH D:\xampp\htdocs\bds\resources\views/admin/course_lesson/getcourseLevelVideo.blade.php ENDPATH**/ ?>