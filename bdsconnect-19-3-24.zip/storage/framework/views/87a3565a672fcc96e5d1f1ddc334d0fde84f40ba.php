<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Bds Frontend | Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="<?php echo e(asset('public/asset/css')); ?>/bootstrap.min.css" rel="stylesheet">
    <script src="<?php echo e(asset('public/asset/js')); ?>/bootstrap.bundle.min.js"></script>
    <link href="<?php echo e(asset('public/asset/css')); ?>/style.css" rel="stylesheet">
</head>
<body>
   
    <div class="main-wrapper">
        <div class="white-box">
            <div class="login-form-outer">
                <div class="logo-img">
                    <div class="bds-logo">
                        <img src="<?php echo e(asset('public/asset/img')); ?>/bds.png">
                    </div>
                    <div class="aps-logo">
                        <img src="<?php echo e(asset('public/asset/img')); ?>/aps.png">
                    </div>
                </div>
                <div class="login-form">
                    <h4>Forgot Password</h4>
                    <div class="line"></div>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <form method="POST" action="<?php echo e(route('password.email')); ?>">
                        <?php echo csrf_field(); ?>
                         
                        

                        <div class="form-floating mb-3">
                          <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                          <label for="floatingInput"><?php echo e(__('E-Mail Address')); ?></label>
                           <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                       
                     <a href="<?php echo e(route('login')); ?>">Back to Login</a>

                        <div class="d-flex justify-content-center align-items-center w-100">
                            <button type="submit" name="submit" class="button"><?php echo e(__('Send Password Reset Link')); ?></button>
                        </div>
                    </form>   
                </div>    
            </div>            
        </div>
    </div>
</body>
</html><?php /**PATH /home/swastihomedecor/bds.swastihomedecor.com/resources/views/auth/passwords/email.blade.php ENDPATH**/ ?>