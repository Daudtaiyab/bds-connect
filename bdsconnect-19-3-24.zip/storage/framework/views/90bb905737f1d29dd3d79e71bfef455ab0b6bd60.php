<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Bds Frontend | Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="<?php echo e(asset('public/asset/css')); ?>/bootstrap.min.css" rel="stylesheet">
    <script src="<?php echo e(asset('public/asset/js')); ?>/bootstrap.bundle.min.js"></script>
    <link href="<?php echo e(asset('public/asset/css')); ?>/style.css" rel="stylesheet">
</head>
<body>
    <?php if(isset($_COOKIE['login_email']) && isset($_COOKIE['login_pass']))
                   {
                      $login_email = $_COOKIE['login_email'];
                      $login_pass  = $_COOKIE['login_pass'];
                      $is_remember = "checked='checked'";
                   }
                   else{
                      $login_email ='';
                      $login_pass = '';
                      $is_remember = "";
                    }
                   ?>
    <?php if(Auth::check() && Auth::user()->user_role_id=='1'): ?>
      <script>
    window.location = '<?php echo e(route("home")); ?>';
  </script>
  <?php elseif(Auth::check() && Auth::user()->user_role_id=='2'): ?>
    <script>
    window.location = '<?php echo e(route("deviceForm")); ?>';
  </script>
    <?php endif; ?>               
    <div class="main-wrapper">
        <div class="white-box">
            <div class="login-form-outer">
                <div class="container">
                        <div class="row d-flex justify-content-center align-items-center w-100">
                            <div class="col-md-9">
                                <div class="connect-design">
                                    <div class="row w-100 g-0">
                                        <div class="col-md-7">
                                            <div class="logo-img">
                                                <div class="bds-logo">
                                                    <img src="<?php echo e(asset('public/asset/img')); ?>/bds.png">
                                                </div>
                                                <h3><span>Coding</span> is the new <span>english</span> of <span>tomorrow</span></h3>
                                            </div>
                                        </div>
                                        <div class="col-md-5 p-4">
                                            <div class="login-form">
                                                <h4>Login</h4>
                                                <?php echo $__env->make('layouts.noftification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                <div class="line"></div>
                                                <form method="POST" action="<?php echo e(route('login')); ?>">
                                                    <?php echo csrf_field(); ?>
                                                   
                                                    <div class="form-floating mb-3">
                                                      <select class="form-control" name="user_role_id" id="user_role_id" required="">
                                                        <option value="">--Select User Type--</option>
                                                          <option value="2">User</option>
                                                          <option value="1">Admin</option>
                                                      </select>
                                                    </div>
                            
                                                    <div class="form-floating mb-3">
                                                       <input id="email" type="text" class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email') ?? $login_email); ?>" required autocomplete="email" autofocus>
                                                      <label for="floatingInput">Username</label>
                                                       <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($message); ?></strong>
                                                                </span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                    <div class="form-floating mb-3">
                            
                                                       <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password" value="<?php echo e($login_pass); ?>">
                                                      <label for="floatingPassword">Password</label>
                                                      <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($message); ?></strong>
                                                                </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                            
                                                    <div class="d-flex justify-content-between align-items-center w-100">
                                                        <label class="text-white">
                                                        <input type="checkbox" name="rememberme" <?php echo e($is_remember); ?>>
                                                        Remember me </label>
                                                        <a href="<?php echo e(route('password.request')); ?>" class="fr rememberme">Forget Password</a>
                                                     </div>
                            
                                                    <div class="d-flex justify-content-center align-items-center w-100">
                                                        <button type="submit" name="submit" class="button">Login Now</button>&nbsp;
                                                        <!--<a href="<?php echo e(route('userregister')); ?>"><button type="button" name="submit" class="button">Register</button></a>-->
                                                    </div>
                                                </form>   
                                            </div>
                                        </div>
                                    </div>
                                </div>    
                            </div>
                        </div>
                </div>    
                
                    
            </div>            
        </div>
    </div>
</body>
</html><?php /**PATH /home/u421606900/domains/bdsconnect.in/public_html/portal/resources/views/auth/login.blade.php ENDPATH**/ ?>