
    <?php $__env->startSection('content'); ?>
<div class="div-padding">
                        
                        <div class="registration-form-outer">
                            <div class="login-form">
                             <?php echo $__env->make('layouts.noftification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <h4>Add Course</h4>
                                <div class="line"></div>
                                <form action="<?php echo e(route('addCourse')); ?>" method="post" enctype="multipart/form-data">
                                  <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-floating mb-3">
                                              <select  class="form-control" id="teaching_id" name="teaching_id" required="">
                                                <option value="">--Select Teaching Option--</option>
                                                <?php if(isset($TeachingOtption) && !empty($TeachingOtption)): ?>
                                                  <?php $__currentLoopData = $TeachingOtption; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $options): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($options['id']); ?>" selected=""><?php echo e($options['option_name']); ?></option>
                                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                              </select>
                                              <label for="floatingInput">Select Teaching Option</label>
                                              <span style="color: red;"><?php echo e($errors->first('teaching_id')); ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-floating mb-3">
                                              <input type="text" class="form-control" id="course_name"  name="course_name" placeholder="Password" required value="<?php echo e(old('course_name')); ?>">
                                              <label for="floatingPassword">Course Titile</label>
                                               <span style="color: red;"><?php echo e($errors->first('course_name')); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-floating mb-3">
                                              <input type="file" class="form-control" id="course_img"  name="course_img" placeholder="Password" required value="<?php echo e(old('course_name')); ?>">
                                              <label for="floatingPassword">Course Image</label>
                                               <span style="color: red;"><?php echo e($errors->first('course_img')); ?></span>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <div class="form-floating mb-3">
                                              <input type="text" class="form-control" id="course_heading"  name="course_heading" placeholder="Password" required value="<?php echo e(old('course_heading')); ?>">
                                              <label for="floatingPassword">Course Heading</label>
                                               <span style="color: red;"><?php echo e($errors->first('course_heading')); ?></span>
                                            </div>
                                        </div>

                                         <div class="col-md-6">
                                            <div class="form-floating mb-3">
                                              <input type="text" class="form-control" id="course_subheading"  name="course_subheading" placeholder="Password" required value="<?php echo e(old('course_subheading')); ?>">
                                              <label for="floatingPassword">Course Sub Heading</label>
                                               <span style="color: red;"><?php echo e($errors->first('course_subheading')); ?></span>
                                            </div>
                                        </div>
                                        
                                          
                                    
                                    <div class="d-flex justify-content-center align-items-center w-100">
                                        <button type="submit" name="submit" class="button">Add Course</button>
                                    </div>
                                </form>   
                            </div>    
                        </div>
                    </div>

        <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u421606900/domains/bdsconnect.in/public_html/portal/resources/views/admin/course/addcourse.blade.php ENDPATH**/ ?>