
    <?php $__env->startSection('content'); ?>
       <div class="div-padding">
                        <div class="admin-heading">
                            <h4>All Courses</h4>
                            <div class="line"></div>
                        </div>
                        <form method="post" action="<?php echo e(route('AssignCourseToUserSave')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="editId" value="<?php echo e($userData->id); ?>">
                            <div class="products">
                                <div class="row d-flex justify-content-center align-items-center">
                                    <!-- start loop -->
                                    <?php
                                        $oldArr=[];
                                    ?>
                                    <?php if(isset($CourseList) && !empty($CourseList)): ?>
                                        <?php $__currentLoopData = $CourseList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coursedata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-4 mb-4">
                                        <label for="codeyrockey_<?php echo e($coursedata['id']); ?>">
                                            <input type="checkbox" id="codeyrockey_<?php echo e($coursedata['id']); ?>" class="checkbox" value="<?php echo e($coursedata['id']); ?>" name="courseassign[]" <?php if(in_array($coursedata['id'],$AssignUserCourse)): ?> <?php echo e('checked'); ?> <?php echo e('disabled'); ?> <?php endif; ?>>
                                            
                                            <?php if(in_array($coursedata['id'],$AssignUserCourse)): ?>
                                                <input type="hidden" id="codeyrockey_<?php echo e($coursedata['id']); ?>" class="checkbox" value="<?php echo e($coursedata['id']); ?>" name="courseassign[]">
                                            <?php endif; ?>
                                            
                                            <div class="card">
                                                <div class="card-img">
                                                    <img src="<?php echo e(asset('public/uploads/product')); ?>/<?php echo e($coursedata['course_img']); ?>" width="100%">
                                                </div>
                                                <div class="card-info">
                                                    <p class="text-title"><?php echo e($coursedata['course_name']); ?> </p>
                                                    <div class="button no-border">Assign Course</div>
                                                </div>
                                            </div>
                                        </label>
                                    </div>
                                    <?php if(in_array($coursedata['id'],$AssignUserCourse)): ?> 
                                    
                                        <input type="hidden" name="OldCourse[]" value="<?php echo e($coursedata['id']); ?>">
                                     <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                    
                                    <div class="d-flex justify-content-center align-items-center w-100">
                                        <button type="submit" name="submit" class="button">Assign Course</button>
                                    </div>
                                    
                                </div>
                            </div>
                        </form>    
                    </div>
             <script src="<?php echo e(asset('public/asset/js')); ?>/jquery-3.6.1.min.js"></script>
    
    <script type="text/javascript">
        $(document).ready(function () {
            $('#edittable').DataTable({
                scrollY: true,
                scrollX: true,
            });
        });
    </script>        
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u421606900/domains/bdsconnect.in/public_html/portal/resources/views/admin/school/assign_course.blade.php ENDPATH**/ ?>