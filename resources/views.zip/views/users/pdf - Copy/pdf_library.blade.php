@extends('users.inc.layout')
    
    @section('content')
    <div class="div-padding">
        <div class="code-library">
            <div class="row">
                <div class="col-md-3">
                    <div class="codebox-outer">
                        <div class="code-box">
                            <img src="img/mblock-logo.png">
                            <h6>Project 1</h6>
                            <div class="line"></div>
                            <button class="download-btn"><span>Download</span> <i class="bi bi-download"></i></button>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="codebox-outer">
                        <div class="code-box">
                            <img src="img/mblock-logo.png">
                            <h6>Project 1</h6>
                            <div class="line"></div>
                            <button class="download-btn"><span>Download</span> <i class="bi bi-download"></i></button>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="codebox-outer">
                        <div class="code-box">
                            <img src="img/mblock-logo.png">
                            <h6>Project 1</h6>
                            <div class="line"></div>
                            <button class="download-btn"><span>Download</span> <i class="bi bi-download"></i></button>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="codebox-outer">
                        <div class="code-box">
                            <img src="img/mblock-logo.png">
                            <h6>Project 1</h6>
                            <div class="line"></div>
                            <button class="download-btn"><span>Download</span> <i class="bi bi-download"></i></button>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="codebox-outer">
                        <div class="code-box">
                            <img src="img/mblock-logo.png">
                            <h6>Project 1</h6>
                            <div class="line"></div>
                            <button class="download-btn"><span>Download</span> <i class="bi bi-download"></i></button>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="codebox-outer">
                        <div class="code-box">
                            <img src="img/mblock-logo.png">
                            <h6>Project 1</h6>
                            <div class="line"></div>
                            <button class="download-btn"><span>Download</span> <i class="bi bi-download"></i></button>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="codebox-outer">
                        <div class="code-box">
                            <img src="img/mblock-logo.png">
                            <h6>Project 1</h6>
                            <div class="line"></div>
                            <button class="download-btn"><span>Download</span> <i class="bi bi-download"></i></button>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="codebox-outer">
                        <div class="code-box">
                            <img src="img/mblock-logo.png">
                            <h6>Project 1</h6>
                            <div class="line"></div>
                            <button class="download-btn"><span>Download</span> <i class="bi bi-download"></i></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @endsection